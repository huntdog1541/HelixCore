#ifndef __STDNORETURN_H
#define __STDNORETURN_H

#define noreturn _Noreturn

#endif
